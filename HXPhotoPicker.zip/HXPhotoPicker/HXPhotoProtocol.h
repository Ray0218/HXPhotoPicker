//
//  HXPhotoProtocol.h
//  照片选择器
//
//  Created by 洪欣 on 2019/11/4.
//  Copyright © 2019 洪欣. All rights reserved.
//

#import <Foundation/Foundation.h>

// 未完成

NS_ASSUME_NONNULL_BEGIN

@protocol HXPhotoProtocol <NSObject>
@end

@protocol HXPhotoBottomViewProtocol <NSObject>

@end

@protocol HXPhotoPreviewBottomViewProtocol <NSObject>

@end

NS_ASSUME_NONNULL_END
