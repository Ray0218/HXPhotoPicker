//
//  HXPhotoPreviewImageViewCell.h
//  照片选择器
//
//  Created by 洪欣 on 2019/12/5.
//  Copyright © 2019 洪欣. All rights reserved.
//

#import "HXPhotoPreviewViewCell.h"
#import "HXPreviewContentView.h"

NS_ASSUME_NONNULL_BEGIN

@interface HXPhotoPreviewImageViewCell : HXPhotoPreviewViewCell
@end

NS_ASSUME_NONNULL_END
