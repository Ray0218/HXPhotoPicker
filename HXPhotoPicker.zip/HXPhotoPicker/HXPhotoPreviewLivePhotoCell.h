//
//  HXPhotoPreviewLivePhotoCell.h
//  照片选择器
//
//  Created by 洪欣 on 2019/12/14.
//  Copyright © 2019 洪欣. All rights reserved.
//

#import "HXPhotoPreviewViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HXPhotoPreviewLivePhotoCell : HXPhotoPreviewViewCell

@end

NS_ASSUME_NONNULL_END
