//
//  HXCircleProgressView.h
//  照片选择器
//
//  Created by 洪欣 on 2017/5/18.
//  Copyright © 2017年 洪欣. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HXCircleProgressView : UIView
@property (nonatomic, assign) CGFloat progress;

- (void)showError;
@end
